Project Title: Language Translation Tool (English to Hindi)
Language: C Programming

Description:
This tool simulates a basic language translator that translates common English phrases into Hindi.
Supported translations include: "hello", "thank you", "goodbye", and "how are you".

How to Run:
1. Compile the program using any C compiler:
   gcc language_translator.c -o translator

2. Run the program:
   ./translator

3. Enter one of the supported phrases to see the translation.

Author: [Your Name]
